CREATE DATABASE IF NOT EXISTS controlbill
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE controlbill;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  monthly_limit DECIMAL(10,2) DEFAULT 0.00,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  type ENUM('receita','despesa') NOT NULL,
  category VARCHAR(80) NOT NULL,
  description VARCHAR(255),
  amount DECIMAL(10,2) NOT NULL,
  date DATE NOT NULL,
  status ENUM('pago','pendente') DEFAULT 'pendente',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_transactions_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE
);

-- Regra de negócio simples:
-- VIEW de resumo mensal (pode ser usada depois se quiser)
CREATE OR REPLACE VIEW monthly_summary AS
SELECT 
  user_id,
  DATE_FORMAT(date, '%Y-%m') AS year_month,
  SUM(CASE WHEN type = 'receita' THEN amount ELSE 0 END) AS total_receitas,
  SUM(CASE WHEN type = 'despesa' THEN amount ELSE 0 END) AS total_despesas
FROM transactions
GROUP BY user_id, DATE_FORMAT(date, '%Y-%m');
