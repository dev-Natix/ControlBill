<?php
// 1) Carregar dependências básicas (sem imprimir HTML ainda)
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/flash.php';

// 2) Tratamento do POST ANTES de mandar qualquer HTML
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name          = trim($_POST['name'] ?? '');
    $email         = trim($_POST['email'] ?? '');
    $password      = $_POST['password'] ?? '';
    $password_conf = $_POST['password_conf'] ?? '';
    $monthly_limit = $_POST['monthly_limit'] !== '' ? (float)$_POST['monthly_limit'] : 0;

    $errors = [];

    if ($name === '') {
        $errors[] = 'Nome é obrigatório.';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'E-mail inválido.';
    }

    if (strlen($password) < 6) {
        $errors[] = 'Senha deve ter pelo menos 6 caracteres.';
    }

    if ($password !== $password_conf) {
        $errors[] = 'Confirmação de senha não confere.';
    }

    if ($monthly_limit < 0) {
        $errors[] = 'Limite mensal não pode ser negativo.';
    }

    // Verifica se já existe usuário com esse e-mail
    $existing = find_user_by_email($email);
    if ($existing) {
        $errors[] = 'Já existe um usuário com esse e-mail.';
    }

    if (!empty($errors)) {
        foreach ($errors as $err) {
            set_flash('error', $err);
        }
        header('Location: ' . BASE_URL . '/register.php');
        exit;
    }

    // Se chegou até aqui, tenta inserir de fato
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'INSERT INTO users (name, email, password_hash, monthly_limit) VALUES (?, ?, ?, ?)'
        );
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt->execute([$name, $email, $hash, $monthly_limit]);

        set_flash('success', 'Cadastro realizado com sucesso! Faça login.');
        header('Location: ' . BASE_URL . '/login.php');
        exit;

    } catch (PDOException $e) {
        // Se der erro de banco, mostra a mensagem pra gente debugar
        set_flash('error', 'Erro ao salvar usuário: ' . $e->getMessage());
        header('Location: ' . BASE_URL . '/register.php');
        exit;
    }
}

// 3) A partir daqui é só a tela (GET)
require_once __DIR__ . '/../includes/header.php';
?>

<section class="auth-wrapper">
    <div class="card auth-card">
        <h1>Criar conta</h1>
        <form method="post" class="js-validate" novalidate>
            <div class="form-group">
                <label>Nome</label>
                <input type="text" name="name" required>
            </div>

            <div class="form-group">
                <label>E-mail</label>
                <input type="email" name="email" required>
            </div>

            <div class="form-group">
                <label>Senha</label>
                <input type="password" name="password" minlength="6" required>
            </div>

            <div class="form-group">
                <label>Confirmar senha</label>
                <input type="password" name="password_conf" minlength="6" required>
            </div>

            <div class="form-group">
                <label>Limite mensal de despesas (R$)</label>
                <input type="number" step="0.01" min="0" name="monthly_limit">
            </div>

            <button type="submit" class="btn-primary">Registrar</button>
            <p class="text-muted">
                Já tem conta? <a href="<?= BASE_URL ?>/login.php">Entrar</a>
            </p>
        </form>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
