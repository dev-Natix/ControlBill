<?php
require_once __DIR__ . '/../includes/header.php';
require_login();

$user_id = current_user_id();
$pdo = getPDO();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$editing = $id > 0;

$transaction = [
    'id'          => '',
    'type'        => 'despesa',
    'category'    => '',
    'description' => '',
    'amount'      => '',
    'date'        => date('Y-m-d'),
    'status'      => 'pendente'
];

if ($editing) {
    $stmt = $pdo->prepare('SELECT * FROM transactions WHERE id = ? AND user_id = ? LIMIT 1');
    $stmt->execute([$id, $user_id]);
    $found = $stmt->fetch();
    if ($found) {
        $transaction = $found;
    } else {
        set_flash('error', 'Lançamento não encontrado.');
        header('Location: ' . BASE_URL . '/transactions_list.php');
        exit;
    }
}
?>

<section class="page-header">
    <h1><?= $editing ? 'Editar lançamento' : 'Novo lançamento' ?></h1>
</section>

<section class="card">
    <form method="post" action="<?= BASE_URL ?>/transaction_save.php" class="js-validate" novalidate>
        <input type="hidden" name="id" value="<?= htmlspecialchars((string)$transaction['id']) ?>">

        <div class="grid grid-2">
            <div class="form-group">
                <label>Tipo</label>
                <select name="type" required>
                    <option value="receita" <?= $transaction['type'] === 'receita' ? 'selected' : '' ?>>Receita</option>
                    <option value="despesa" <?= $transaction['type'] === 'despesa' ? 'selected' : '' ?>>Despesa</option>
                </select>
            </div>

            <div class="form-group">
                <label>Categoria</label>
                <input type="text" name="category" required
                       value="<?= htmlspecialchars($transaction['category']) ?>"
                       placeholder="Ex.: Salário, Aluguel, Mercado">
            </div>
        </div>

        <div class="form-group">
            <label>Descrição</label>
            <input type="text" name="description"
                   value="<?= htmlspecialchars($transaction['description']) ?>">
        </div>

        <div class="grid grid-3">
            <div class="form-group">
                <label>Valor (R$)</label>
                <input type="number" name="amount" step="0.01" min="0.01" required
                       value="<?= htmlspecialchars((string)$transaction['amount']) ?>">
            </div>

            <div class="form-group">
                <label>Data</label>
                <input type="date" name="date" required
                       value="<?= htmlspecialchars($transaction['date']) ?>">
            </div>

            <div class="form-group">
                <label>Status</label>
                <select name="status" required>
                    <option value="pago" <?= $transaction['status'] === 'pago' ? 'selected' : '' ?>>Pago</option>
                    <option value="pendente" <?= $transaction['status'] === 'pendente' ? 'selected' : '' ?>>Pendente</option>
                </select>
            </div>
        </div>

        <p class="text-muted small">
            Regra de negócio: despesas não podem ter valor negativo 
            e datas futuras são permitidas apenas para lançamentos pendentes.
        </p>

        <div class="form-actions">
            <button type="submit" class="btn-primary">
                <?= $editing ? 'Salvar alterações' : 'Salvar lançamento' ?>
            </button>
            <a href="<?= BASE_URL ?>/transactions_list.php" class="btn-secondary">Cancelar</a>
        </div>
    </form>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
