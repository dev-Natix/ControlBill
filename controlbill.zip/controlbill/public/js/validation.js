document.addEventListener('DOMContentLoaded', function () {
    const forms = document.querySelectorAll('form.js-validate');

    forms.forEach(form => {
        form.addEventListener('submit', function (e) {
            let valid = true;
            const requiredFields = form.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                field.classList.remove('field-error');
                if (!field.value || field.value.trim() === '') {
                    valid = false;
                    field.classList.add('field-error');
                }
            });

            // valida valor (se houver campo amount)
            const amountField = form.querySelector('input[name="amount"]');
            if (amountField) {
                const val = parseFloat(amountField.value.replace(',', '.'));
                if (isNaN(val) || val <= 0) {
                    valid = false;
                    amountField.classList.add('field-error');
                    alert('Informe um valor maior que zero.');
                }
            }

            if (!valid) {
                e.preventDefault();
            }
        });
    });
});
