<?php
require_once __DIR__ . '/../includes/header.php';

if (is_logged_in()) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $user = find_user_by_email($email);

    if ($user && password_verify($password, $user['password_hash'])) {
        login_user((int)$user['id']);
        set_flash('success', 'Bem-vindo de volta, ' . $user['name'] . '!');
        header('Location: ' . BASE_URL . '/dashboard.php');
        exit;
    } else {
        set_flash('error', 'E-mail ou senha inválidos.');
    }
}
?>

<section class="auth-wrapper">
    <div class="card auth-card">
        <h1>Login</h1>
        <form method="post" class="js-validate" novalidate>
            <div class="form-group">
                <label>E-mail</label>
                <input type="email" name="email" required>
            </div>

            <div class="form-group">
                <label>Senha</label>
                <input type="password" name="password" minlength="6" required>
            </div>

            <button type="submit" class="btn-primary">Entrar</button>
            <p class="text-muted">
                Ainda não tem conta? <a href="<?= BASE_URL ?>/register.php">Criar conta</a>
            </p>
        </form>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
