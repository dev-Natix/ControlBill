<?php
require_once __DIR__ . '/../includes/header.php';
require_login();

$user_id = current_user_id();
$pdo = getPDO();

$filter_month = $_GET['month'] ?? date('Y-m');

$stmt = $pdo->prepare("
    SELECT * 
    FROM transactions
    WHERE user_id = ?
      AND DATE_FORMAT(date, '%Y-%m') = ?
    ORDER BY date DESC, id DESC
");
$stmt->execute([$user_id, $filter_month]);
$rows = $stmt->fetchAll();
?>

<section class="page-header">
    <h1>Lançamentos</h1>
    <div class="page-header-actions">
        <form method="get" class="filter-form">
            <label>Mês:</label>
            <input type="month" name="month" value="<?= htmlspecialchars($filter_month) ?>">
            <button type="submit" class="btn-secondary">Filtrar</button>
        </form>
        <a href="<?= BASE_URL ?>/transactions_form.php" class="btn-primary">Novo lançamento</a>
    </div>
</section>

<section class="card">
    <?php if (empty($rows)): ?>
        <p>Você ainda não tem lançamentos neste período.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Tipo</th>
                        <th>Categoria</th>
                        <th>Descrição</th>
                        <th>Status</th>
                        <th class="text-right">Valor (R$)</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $t): ?>
                    <tr>
                        <td><?= date('d/m/Y', strtotime($t['date'])) ?></td>
                        <td>
                            <span class="tag <?= $t['type'] === 'receita' ? 'tag-income' : 'tag-expense' ?>">
                                <?= htmlspecialchars($t['type']) ?>
                            </span>
                        </td>
                        <td><?= htmlspecialchars($t['category']) ?></td>
                        <td><?= htmlspecialchars($t['description']) ?></td>
                        <td>
                            <span class="tag <?= $t['status'] === 'pago' ? 'tag-paid' : 'tag-pending' ?>">
                                <?= htmlspecialchars($t['status']) ?>
                            </span>
                        </td>
                        <td class="text-right">
                            <?= number_format($t['amount'], 2, ',', '.') ?>
                        </td>
                        <td>
                            <a class="btn-link" href="<?= BASE_URL ?>/transactions_form.php?id=<?= $t['id'] ?>">Editar</a>
                            <a class="btn-link text-danger"
                               href="<?= BASE_URL ?>/transaction_delete.php?id=<?= $t['id'] ?>"
                               onclick="return confirm('Tem certeza que deseja excluir este lançamento?');">
                               Excluir
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
