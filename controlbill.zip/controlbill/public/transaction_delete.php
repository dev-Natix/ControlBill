<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();

$user_id = current_user_id();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $pdo = getPDO();
    $stmt = $pdo->prepare('DELETE FROM transactions WHERE id = ? AND user_id = ?');
    $stmt->execute([$id, $user_id]);
    set_flash('success', 'Lançamento excluído com sucesso.');
} else {
    set_flash('error', 'ID de lançamento inválido.');
}

header('Location: ' . BASE_URL . '/transactions_list.php');
exit;
