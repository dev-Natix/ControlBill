<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();

$user_id = current_user_id();
$pdo = getPDO();

$id          = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$type        = $_POST['type']        ?? '';
$category    = trim($_POST['category'] ?? '');
$description = trim($_POST['description'] ?? '');
$amount      = isset($_POST['amount']) ? (float)$_POST['amount'] : 0;
$date        = $_POST['date']        ?? '';
$status      = $_POST['status']      ?? '';

$errors = [];

// Validações básicas
if (!in_array($type, ['receita','despesa'], true)) {
    $errors[] = 'Tipo inválido.';
}
if ($category === '') {
    $errors[] = 'Categoria é obrigatória.';
}
if ($amount <= 0) {
    $errors[] = 'Valor deve ser maior que zero.';
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    $errors[] = 'Data inválida.';
}
if (!in_array($status, ['pago','pendente'], true)) {
    $errors[] = 'Status inválido.';
}

// Regra de negócio: datas futuras só são permitidas para status pendente
$today = date('Y-m-d');
if ($date > $today && $status === 'pago') {
    $errors[] = 'Não é permitido marcar como pago uma data futura.';
}

// Regra de negócio: checar limite mensal para despesas
if ($type === 'despesa') {
    // Busca limite do usuário
    $user = find_user_by_id($user_id);
    $limite = (float)$user['monthly_limit'];

    if ($limite > 0) {
        $currentMonth = substr($date, 0, 7); // YYYY-MM
        $sql = "
            SELECT SUM(amount) AS total_despesas
            FROM transactions
            WHERE user_id = ?
              AND type = 'despesa'
              AND DATE_FORMAT(date, '%Y-%m') = ?
        ";

        // Se estiver editando, desconsidera o próprio lançamento antigo
        if ($id > 0) {
            $sql .= " AND id <> ?";
        }

        $stmt = $pdo->prepare($sql);
        if ($id > 0) {
            $stmt->execute([$user_id, $currentMonth, $id]);
        } else {
            $stmt->execute([$user_id, $currentMonth]);
        }

        $row = $stmt->fetch();
        $despesas_mes = (float)($row['total_despesas'] ?? 0);
        $novo_total = $despesas_mes + $amount;

        if ($novo_total > $limite) {
            $errors[] = 'Este lançamento ultrapassa o limite mensal de despesas definido.';
        }
    }
}

if (!empty($errors)) {
    foreach ($errors as $err) {
        set_flash('error', $err);
    }
    // Volta para o form (edição ou novo)
    if ($id > 0) {
        header('Location: ' . BASE_URL . '/transactions_form.php?id=' . $id);
    } else {
        header('Location: ' . BASE_URL . '/transactions_form.php');
    }
    exit;
}

if ($id > 0) {
    // Update
    $stmt = $pdo->prepare("
        UPDATE transactions
        SET type = ?, category = ?, description = ?, amount = ?, date = ?, status = ?
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$type, $category, $description, $amount, $date, $status, $id, $user_id]);
    set_flash('success', 'Lançamento atualizado com sucesso!');
} else {
    // Insert
    $stmt = $pdo->prepare("
        INSERT INTO transactions (user_id, type, category, description, amount, date, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$user_id, $type, $category, $description, $amount, $date, $status]);
    set_flash('success', 'Lançamento criado com sucesso!');
}

header('Location: ' . BASE_URL . '/transactions_list.php');
exit;
