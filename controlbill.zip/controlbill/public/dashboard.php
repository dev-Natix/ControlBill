<?php
require_once __DIR__ . '/../includes/header.php';
require_login();

$user_id = current_user_id();
$user    = find_user_by_id($user_id);

$pdo = getPDO();

// Totais gerais
$stmt = $pdo->prepare("
    SELECT
        SUM(CASE WHEN type = 'receita' THEN amount ELSE 0 END) AS total_receitas,
        SUM(CASE WHEN type = 'despesa' THEN amount ELSE 0 END) AS total_despesas
    FROM transactions
    WHERE user_id = ?
");
$stmt->execute([$user_id]);
$totais = $stmt->fetch() ?: ['total_receitas' => 0, 'total_despesas' => 0];

$receitas = (float)($totais['total_receitas'] ?? 0);
$despesas = (float)($totais['total_despesas'] ?? 0);
$saldo    = $receitas - $despesas;

// Despesas do mês atual para checar limite
$currentMonth = date('Y-m');
$stmt = $pdo->prepare("
    SELECT SUM(amount) AS despesas_mes
    FROM transactions
    WHERE user_id = ?
      AND type = 'despesa'
      AND DATE_FORMAT(date, '%Y-%m') = ?
");
$stmt->execute([$user_id, $currentMonth]);
$row = $stmt->fetch();
$despesas_mes = (float)($row['despesas_mes'] ?? 0);
$limite       = (float)$user['monthly_limit'];

$percent_limite = $limite > 0 ? min(100, ($despesas_mes / $limite) * 100) : 0;

?>

<section class="page-header">
    <h1>Olá, <?= htmlspecialchars($user['name']) ?> 👋</h1>
    <p class="subtitle">Veja um resumo rápido das suas finanças.</p>
</section>

<section class="grid grid-3">
    <div class="card stat-card income">
        <span class="stat-label">Receitas totais</span>
        <span class="stat-value">R$ <?= number_format($receitas, 2, ',', '.') ?></span>
    </div>

    <div class="card stat-card expense">
        <span class="stat-label">Despesas totais</span>
        <span class="stat-value">R$ <?= number_format($despesas, 2, ',', '.') ?></span>
    </div>

    <div class="card stat-card balance">
        <span class="stat-label">Saldo atual</span>
        <span class="stat-value">R$ <?= number_format($saldo, 2, ',', '.') ?></span>
    </div>
</section>

<section class="card limit-card">
    <div class="limit-header">
        <h2>Limite mensal de despesas</h2>
        <span class="chip">
            Limite: R$ <?= number_format($limite, 2, ',', '.') ?>
        </span>
    </div>
    <p>Despesas do mês (<?= date('m/Y') ?>): 
        <strong>R$ <?= number_format($despesas_mes, 2, ',', '.') ?></strong>
    </p>

    <div class="progress-bar">
        <div class="progress-fill" style="width: <?= $percent_limite ?>%;"></div>
    </div>

    <?php if ($limite > 0 && $despesas_mes > $limite): ?>
        <p class="text-danger">
            Você ultrapassou o limite mensal definido. Reveja seus gastos!
        </p>
    <?php elseif ($limite > 0 && $percent_limite > 80): ?>
        <p class="text-warning">
            Atenção: você já usou mais de 80% do seu limite mensal.
        </p>
    <?php else: ?>
        <p class="text-success">
            Você está dentro do limite mensal definido. Continue assim. ✨
        </p>
    <?php endif; ?>

    <div class="limit-actions">
        <a href="<?= BASE_URL ?>/transactions_form.php" class="btn-primary">Novo lançamento</a>
        <a href="<?= BASE_URL ?>/transactions_list.php" class="btn-secondary">Ver todos</a>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
