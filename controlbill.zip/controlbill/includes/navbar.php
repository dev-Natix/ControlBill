<?php $logged = is_logged_in(); ?>
<header class="topbar">
    <div class="topbar-inner">
        <div class="brand">
            <span class="brand-logo">CB</span>
            <span class="brand-text">ControlBill - Natã Bonfante de Oliveira - 2024203303</span>
        </div>
        <nav class="nav-links">
            <?php if ($logged): ?>
                <a href="<?= BASE_URL ?>/dashboard.php">Dashboard</a>
                <a href="<?= BASE_URL ?>/transactions_list.php">Lançamentos</a>
                <a href="<?= BASE_URL ?>/transactions_form.php">Novo Lançamento</a>
                <a href="<?= BASE_URL ?>/logout.php" class="btn-outline">Sair</a>
            <?php else: ?>
                <a href="<?= BASE_URL ?>/login.php">Login</a>
                <a href="<?= BASE_URL ?>/register.php" class="btn-outline">Registrar</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
