<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/flash.php';

function current_user_id(): ?int
{
    return $_SESSION['user_id'] ?? null;
}

function is_logged_in(): bool
{
    return current_user_id() !== null;
}

function require_login(): void
{
    if (!is_logged_in()) {
        set_flash('error', 'Faça login para acessar esta área.');
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function find_user_by_email(string $email): ?array
{
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function find_user_by_id(int $id): ?array
{
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function login_user(int $user_id): void
{
    $_SESSION['user_id'] = $user_id;
}

function logout_user(): void
{
    session_unset();
    session_destroy();
}
