    </main>
    <footer class="footer">
        <p>ControlBill &copy; <?= date('Y') ?> - Natã Bonfante de Oliveira - 2024203303</p>
    </footer>
</body>
</html>
