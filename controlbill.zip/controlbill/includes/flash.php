<?php

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'][] = [
        'type'    => $type,
        'message' => $message
    ];
}

function get_flash(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

function render_flash(): void
{
    $messages = get_flash();
    if (empty($messages)) {
        return;
    }

    foreach ($messages as $msg) {
        $type = htmlspecialchars($msg['type']);
        $text = htmlspecialchars($msg['message']);
        echo "<div class=\"alert alert-{$type}\">{$text}</div>";
    }
}
