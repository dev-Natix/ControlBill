<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ajuste se necessário
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'controlbill');
define('DB_USER', 'root');
define('DB_PASS', 'senha123'); // coloque a senha do MySQL se tiver

define('BASE_URL', '/controlbill/public'); // ajuste se o caminho for diferente
